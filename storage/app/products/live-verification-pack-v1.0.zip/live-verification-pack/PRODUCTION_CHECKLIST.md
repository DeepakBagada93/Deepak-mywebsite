# Production AI Engineering Checklist (Deepak Bagada)

1. [ ] **Budgeted Context:** Never exceed 300 tokens in always-on rules (CLAUDE.md / AGENTS.md).
2. [ ] **0-Dependency Contracts:** Keep stdio MCP servers free of bloated runtime dependencies.
3. [ ] **Automated Retries:** Enforce 3x exponential backoff on third-party LLM and webhook endpoints.
4. [ ] **Hardened Timeouts:** Hard-cap external HTTP tasks at 30 seconds to prevent hanging queues.
5. [ ] **Strict Phase Gates:** Do not advance agency delivery phases without clean artifact audits.
