# 5 Battle-Tested Production Prompts

### 1. Architecture Adjudication Prompt
Role: Senior AI Architect.
Context: Multiple conflicting rules detected across project config and documentation.
Task: Resolve contradictions using strict evidence hierarchy (lockfile > config > documentation).
Constraints: Zero hallucinations. Output single unified kernel under 300 tokens.

### 2. FastMCP Tool Interface Designer
Role: MCP Protocol Engineer.
Context: Designing zero-dependency Node.js MCP server over newline-delimited JSON-RPC.
Task: Write kebab-case schema with input JSON Schema validation.
Constraints: Reject invalid argument types immediately. Provide informative error messages.
